# Stork
A small footprint scripting language with C++ integration.

In this branch, expressions are implemented. You can compile this code and then execute it. You can type-in expressions, and each of them will be evaluated. Then all the variables will be printed on the standard output.

You can assume that there are 6 number variables (a, b, c, d, e, f), 6 string variables (str1, str2, str3, str4, str5, str6), that receives two numbers and returns a number, function "concat_to" that receives one string by reference, second string by value, concats seconds string to the first, and returns the first string. There are also two arrays: numarr, that holds 5 numbers, and strarr, that holds 5 strings.

This project is a work in progress. It is tested under Xcode on Mac. You should be able to compile it with C++17 standard on any platform.
